library myprj_globals;

String user = 'user';
String driverid = '2';
String reselid = '3';