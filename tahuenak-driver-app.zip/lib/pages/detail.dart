// import 'package:first/pages/ahhhhh.dart';
import 'package:first/main.dart';
import 'package:first/pages/history.dart';
import 'package:first/pages/home.dart';
import 'package:flutter/material.dart';
import 'package:first/pages/tunai.dart';
import 'package:first/pages/qrcode.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class Detail extends StatefulWidget {
  List list;
  int index;
  Detail({this.index, this.list});
  @override
  _DetailState createState() => _DetailState();
}

class _DetailState extends State<Detail> {
  bool visible = false;
  Future finish() async {
    // Showing CircularProgressIndicator.
    setState(() {
      visible = true;
    });

    // Getting value from Controller
    String id = widget.list[widget.index]['orderid'];

    // SERVER API URL
    // var url = 'http://trackingalkitab.epizy.com/driver_signup2.php';
    // alternate server https://projectalpha.sytes.net/mobile/driver_finish_order.php
    // server bapaknya http://tahuenak.id/mobile/driver_finish_order.php
    var url = 'https://tahuenak.id/mobile/driver_finish_order.php';
    // Store all data with Param Name.
    var data = {
      'id': id,
    };

    // Starting Web API Call.
    var response = await http.post(url, body: json.encode(data));

    // Getting Server response into variable.
    var message = jsonDecode(response.body);

    // If Web call Success than Hide the CircularProgressIndicator.
    if (response.statusCode == 200) {
      setState(() {
        visible = false;
      });
    }

    // Showing Alert Dialog with Response JSON Message.
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: new Text(message),
          actions: <Widget>[
            FlatButton(
              child: new Text("OK"),
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pop();
                Navigator.of(context).push(MaterialPageRoute(
                                builder: (BuildContext context) => MyApp(),
                              ));
              },
            ),
          ],
        );
      },
    );
  }
  @override
  Widget build(BuildContext context) {
    Widget kartuGeser = Column(
      children: <Widget>[
        ListTile(
          title: Text(
            'Order',
            style: TextStyle(fontSize: 18.0),
            // style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18.0),
          ),
          // trailing: IconButton(
          //   icon: Icon(Icons.keyboard_arrow_right),
          //   onPressed: () {},
          // ),
        ),
        Container(
          width: double.infinity,
          height: 100.0,
          padding: const EdgeInsets.all(8.0),
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: <Widget>[
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.blue,
                        Colors.blue[800],
                      ]),
                  borderRadius: BorderRadius.circular(8.0),
                ),
                // padding: EdgeInsets.all(8.0),
                margin: EdgeInsets.only(left: 8.0),
                height: 100.0,
                width: 110.0,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.all(8.0), // or 13
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Text(
                              widget.list[widget.index]['name'],
                              style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  color: Colors.white,
                                  fontSize: 18.0),
                            ),
                            Text(
                              widget.list[widget.index]['qty'],
                              style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  color: Colors.white,
                                  fontSize: 18.0),
                            )
                          ],
                        ),
                      ),
                    )
                  ],
                ),
              ),
              // Container(
              //   decoration: BoxDecoration(
              //     gradient: LinearGradient(
              //         begin: Alignment.topCenter,
              //         end: Alignment.bottomCenter,
              //         colors: [
              //           Colors.blue,
              //           Colors.blue[800],
              //         ]),
              //     borderRadius: BorderRadius.circular(8.0),
              //   ),
              //   // padding: EdgeInsets.all(8.0),
              //   margin: EdgeInsets.only(left: 8.0),
              //   height: 100.0,
              //   width: 100.0,
              //   child: Column(
              //     crossAxisAlignment: CrossAxisAlignment.start,
              //     children: <Widget>[
              //       Padding(
              //         padding: const EdgeInsets.all(8.0), // or 13
              //         child: Center(
              //           child: Column(
              //             children: <Widget>[
              //               Text(
              //                 'Produk C',
              //                 style: TextStyle(
              //                     fontWeight: FontWeight.w500,
              //                     color: Colors.white,
              //                     fontSize: 18.0),
              //               ),
              //               Text(
              //                 '2',
              //                 style: TextStyle(
              //                     fontWeight: FontWeight.w500,
              //                     color: Colors.white,
              //                     fontSize: 18.0),
              //               )
              //             ],
              //           ),
              //         ),
              //       )
              //     ],
              //   ),
              // ),
              // Container(
              //   decoration: BoxDecoration(
              //     gradient: LinearGradient(
              //         begin: Alignment.topCenter,
              //         end: Alignment.bottomCenter,
              //         colors: [
              //           Colors.blue,
              //           Colors.blue[800],
              //         ]),
              //     borderRadius: BorderRadius.circular(8.0),
              //   ),
              //   // padding: EdgeInsets.all(8.0),
              //   margin: EdgeInsets.only(left: 8.0),
              //   height: 100.0,
              //   width: 100.0,
              //   child: Column(
              //     crossAxisAlignment: CrossAxisAlignment.start,
              //     children: <Widget>[
              //       Padding(
              //         padding: const EdgeInsets.all(8.0), // or 13
              //         child: Center(
              //           child: Column(
              //             children: <Widget>[
              //               Text(
              //                 'Produk C',
              //                 style: TextStyle(
              //                     fontWeight: FontWeight.w500,
              //                     color: Colors.white,
              //                     fontSize: 18.0),
              //               ),
              //               Text(
              //                 '2',
              //                 style: TextStyle(
              //                     fontWeight: FontWeight.w500,
              //                     color: Colors.white,
              //                     fontSize: 18.0),
              //               )
              //             ],
              //           ),
              //         ),
              //       )
              //     ],
              //   ),
              // ),
              // Container(
              //   decoration: BoxDecoration(
              //     gradient: LinearGradient(
              //         begin: Alignment.topCenter,
              //         end: Alignment.bottomCenter,
              //         colors: [
              //           Colors.blue,
              //           Colors.blue[800],
              //         ]),
              //     borderRadius: BorderRadius.circular(8.0),
              //   ),
              //   // padding: EdgeInsets.all(8.0),
              //   margin: EdgeInsets.only(left: 30.0),
              //   height: 100.0,
              //   width: 100.0,
              //   child: Column(
              //     crossAxisAlignment: CrossAxisAlignment.start,
              //     children: <Widget>[
              //       Padding(
              //         padding: const EdgeInsets.all(8.0),
              //         child: Center(
              //           child: Text(
              //             '1 \nProduk A',
              //             style: TextStyle(
              //                 fontWeight: FontWeight.w500,
              //                 color: Colors.white,
              //                 fontSize: 18.0),
              //           ),
              //         ),
              //       )
              //     ],
              //   ),
              // ),
            ],
          ),
        )
      ],
    );

    Widget namaDriver = Container(
      padding: EdgeInsets.all(16),
      child: Row(
        children: [
          Text(
            'Nama',
            style: TextStyle(fontSize: 18),
          ),
          Text(
            ':  ',
            style: TextStyle(fontSize: 18),
          ),
          Padding(
              padding: EdgeInsets.only(left: 10),
              child: Text(
                'Nama Driver',
                style: TextStyle(fontSize: 18),
              )),
        ],
      ),
    );

    Container _buildDetail(String label, String isi){
      return Container(
      padding: EdgeInsets.all(16),
      child: Row(
        children: [
          Text(
            label,
            style: TextStyle(fontSize: 18),
          ),
          Text(
            ':  ',
            style: TextStyle(fontSize: 18),
          ),
          Padding(
              padding: EdgeInsets.only(left: 10),
              child: Text(
                isi,
                style: TextStyle(fontSize: 18),
              )),
        ],
      ),
    );
    }

    Container _buildText(String label, String isi){
      return Container(
      padding: EdgeInsets.all(16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Expanded(
            child: Text(
                label+': ',
                style: TextStyle(fontSize: 18),
              ),
          ),
          Expanded(
            child: Text(
                isi,
                style: TextStyle(fontSize: 18),
              ),
          ),
          Expanded(
            child: Text(
                '',
                style: TextStyle(fontSize: 18),
              ),
          ),
          
          
        ],
      ),
    );
    }

    Widget buttonSection = Container(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildButtonColumn(Colors.lightBlue, Icons.attach_money, 'Tunai'),
          _buildButtonColumn(Colors.lightBlue, Icons.filter_center_focus, 'QR'),
          _buildButtonColumn(Colors.lightBlue, Icons.share, 'Finish'),
        ],
      ),
    );

    Widget divider = Container(
      padding: EdgeInsets.symmetric(horizontal: 16),
      height: 20,
      child: Divider(
        color: Colors.grey[500],
        thickness: 2,
        height: 10,
      ),
    );

    Widget order = Container(
      padding: EdgeInsets.all(16),
      child: Column(
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              Card(
                child: Column(
                  children: <Widget>[Text('2'), divider, Text('Tahu 1')],
                ),
              ),
              Card(
                child: Column(
                  children: <Widget>[Text('2'), divider, Text('Tahu 1')],
                ),
              ),
              Card(
                child: Column(
                  children: <Widget>[Text('2'), divider, Text('Tahu 1')],
                ),
              ),
            ],
          )
        ],
      ),
    );

    return Scaffold(
      appBar: AppBar(
        title: Text('Detail')
      ),
          body: ListView(
            children: <Widget>[
              // namaDriver,
              _buildDetail('Nama', widget.list[widget.index]['customername']),
              // _buildDetail('Nama', widget.list[widget.index]['adminid'] != null ? widget.list[widget.index]['customername'] : widget.list[widget.index]['cname']),
              _buildDetail('Alamat', widget.list[widget.index]['address']),
              _buildDetail('Telepon', widget.list[widget.index]['phone']),
              // _buildDetail('Telepon', widget.list[widget.index]['adminid'] != null ? widget.list[widget.index]['phone'] : widget.list[widget.index]['cphone']),
              kartuGeser,
              _buildDetail('Ongkir', 'Free'),
              _buildDetail('Total', widget.list[widget.index]['price']),
              divider,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      GestureDetector(
                        child: Icon(Icons.attach_money, color: Colors.lightBlue),
                        onTap: () =>
                              Navigator.of(context).push(MaterialPageRoute(
                                builder: (BuildContext context) => Tunai(list: widget.list, index: widget.index,),
                              )),
                      ),
                      FlatButton(
                          onPressed: () =>
                              Navigator.of(context).push(MaterialPageRoute(
                                builder: (BuildContext context) => Tunai(list: widget.list, index: widget.index,),
                              )),
                          child: Text(
                            'Tunai',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w400,
                              color: Colors.lightBlue,
                            ),
                          )),
                    ],
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      GestureDetector(
                        child: Icon(Icons.filter_center_focus, color: Colors.lightBlue),
                        onTap: () =>
                              Navigator.of(context).push(new MaterialPageRoute(
                                builder: (BuildContext context) => new Qrcode(list: widget.list,index: widget.index,),
                              )),
                      ),
                      FlatButton(
                          onPressed: () =>
                              Navigator.of(context).push(new MaterialPageRoute(
                                builder: (BuildContext context) => new Qrcode(list: widget.list,index: widget.index,),
                              )),
                          child: Text(
                            'QR Code',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w400,
                              color: Colors.lightBlue,
                            ),
                          )),
                    ],
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      GestureDetector(
                        child: Icon(Icons.check, color: Colors.lightBlue),
                        onTap: finish,
                      ),
                      FlatButton(
                        onPressed: finish,
                          // onPressed: () =>
                          //     Navigator.of(context).push(new MaterialPageRoute(
                          //       builder: (BuildContext context) => new Finish(list: widget.list,index: widget.index,),
                          //     )),
                          child: Text(
                            'Selesai',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w400,
                              color: Colors.lightBlue,
                            ),
                          )),
                    ],
                  ),
                  
                ],
                
              ),
              Column(children: [Visibility(child: CircularProgressIndicator(), visible: visible,)]),
              
            ],
          ),
    );
  }

  Column _buildButtonColumn(Color color, IconData icon, String label) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, color: color),
        // Container(
        //   margin: const EdgeInsets.only(top: 8),
        //   child: Text(
        //     label,
        //     style: TextStyle(
        //       fontSize: 12,
        //       fontWeight: FontWeight.w400,
        //       color: color,
        //     ),
        //   ),
        // ),
        FlatButton(
            onPressed: () {},
            child: Text(
              label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w400,
                color: color,
              ),
            )),
      ],
    );
  }
}
