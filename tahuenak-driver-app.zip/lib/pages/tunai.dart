import 'package:first/main.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:first/global.dart' as globals;

class Tunai extends StatefulWidget {
  List list;
  int index;
  Tunai({this.index, this.list});
  @override
  _TunaiState createState() => _TunaiState();
}

class _TunaiState extends State<Tunai> {
  var kembali = '0';
  void hitungKembali(String par) {
    setState(() {
      int total = int.parse(widget.list[widget.index]['price']);

      int terima = int.parse(controllerTerima.text);

      int change = terima - total;

      kembali = change.toString();

      par = kembali;
    });
  }

  bool visible;
  TextEditingController controllerTerima = new TextEditingController();
  TextEditingController controllerKembali = new TextEditingController();
  Future finish() async {
    // Showing CircularProgressIndicator.
    setState(() {
      visible = true;
    });

    // Getting value from Controller
    String id = widget.list[widget.index]['orderid'];

    // SERVER API URL
    // var url = 'http://trackingalkitab.epizy.com/driver_signup2.php';
    // alternate server https://projectalpha.sytes.net/mobile/driver_finish_order.php
    // server bapaknya http://tahuenak.id/mobile/driver_finish_order.php
    var url =
        'https://tahuenak.id/mobile/driver_finish_order.php';
    // Store all data with Param Name.
    var data = {
      'id': id,
    };

    // Starting Web API Call.
    var response = await http.post(url, body: json.encode(data));

    // Getting Server response into variable.
    var message = jsonDecode(response.body);

    // If Web call Success than Hide the CircularProgressIndicator.
    if (response.statusCode == 200) {
      setState(() {
        visible = false;
      });
    }

    // Showing Alert Dialog with Response JSON Message.
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: new Text(message),
          actions: <Widget>[
            FlatButton(
              child: new Text("OK"),
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pop();
                Navigator.of(context).push(MaterialPageRoute(
                                builder: (BuildContext context) => MyApp(),
                              ));
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final buttonSelesai = Padding(
      padding: EdgeInsets.all(16),
      child: RaisedButton(
        onPressed: finish,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        padding: EdgeInsets.all(12),
        color: Theme.of(context).primaryColor,
        child: Text(
          'Selesai',
          style: TextStyle(color: Colors.white),
        ),
      ),
    );
    return Scaffold(
      appBar: AppBar(
        title: Text('Tunai'),
      ),
      body: Center(
        child: ListView(
          children: <Widget>[
            _buildName('Total', widget.list[widget.index]['price']),
            Container(
              padding: EdgeInsets.all(16),
              child: Column(
                children: [
                  Row(
                    children: <Widget>[
                      Text(
                        'Terima',
                        style: TextStyle(fontSize: 18),
                      ),
                    ],
                  ),
                  TextField(
                    onChanged: hitungKembali,
                    controller: controllerTerima,
                    decoration: InputDecoration(hintText: 'Nominal'),
                  )
                ],
              ),
            ),

            _buildName('Kembali', kembali),
            // Text(
            //   widget.list[widget.index]['orderid']

            // ),

            buttonSelesai,
            // Column(
            //     children: <Widget>[
            //       Visibility(visible: visible,child: CircularProgressIndicator()),
            //     ],
            //   ),
          ],
        ),
      ),
    );
  }

  Container _buildForm(String label, TextEditingController controller) {
    return Container(
      padding: EdgeInsets.all(16),
      child: Column(
        children: [
          Row(
            children: <Widget>[
              Text(
                label,
                style: TextStyle(fontSize: 18),
              ),
            ],
          ),
          TextFormField(
            controller: controller,
            decoration: InputDecoration(hintText: 'Nominal'),
          )
        ],
      ),
    );
  }

  Container _buildName(String label, String isi) {
    return Container(
        padding: EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Expanded(
              child: Text(
                label,
                style: TextStyle(
                  fontSize: 18,
                ),
              ),
            ),
            Expanded(
              child: Text(
                isi,
                style: TextStyle(
                  fontSize: 18,
                ),
              ),
            ),
            Expanded(
              child: Text(
                '',
                style: TextStyle(
                  fontSize: 18,
                ),
              ),
            ),
            Expanded(
              child: Text(
                '',
                style: TextStyle(
                  fontSize: 18,
                ),
              ),
            ),
          ],
        ));
  }
}
