import 'dart:convert';
import 'dart:ui';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:first/global.dart' as globals;

class History extends StatefulWidget {
  @override
  _HistoryState createState() => _HistoryState();
}

class _HistoryState extends State<History> {
  String username = globals.user;
  Future<List> getData() async{
    final response = await http.get("https://tahuenak.id/mobile/driver_get_history.php/?user=$username");
    return jsonDecode(response.body);

  }

  @override
  Widget build(BuildContext context) {
    Widget card = Card(
      child: InkWell(
        splashColor: Colors.blue.withAlpha(30),
        onTap: () {
          print('tapped');
          
        },
        child: Container(
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              Expanded(
                /*1*/
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    /*2*/
                    Container(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Text(
                        'Customer Name',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                    ),
                    Text(
                      'Customer Address',
                      style: TextStyle(
                        color: Colors.grey[500],
                        fontSize: 18,
                      ),
                    ),
                    Text(
                      'Delivered At 20 Apr 2020',
                       style: TextStyle(
                         fontSize: 18
                       ),
                    )
                  ],
                ),
              ),
              Container(
                height: 50,
                child: VerticalDivider(
                  color: Colors.grey[400],
                  thickness: 2,
                ),
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    child: Text(
                      'Zone',
                      style: TextStyle(fontSize: 18),
                    ),
                  ),
                  Text(
                    'A',
                    style:
                      TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
    
    return MaterialApp(
      title: 'History',
      home: Scaffold(
        appBar: AppBar(
          title: Text('History'),
        ),
        body: FutureBuilder<List>(
          future: getData(),
          builder: (context, snapshot){
            if(snapshot.hasError) print(snapshot.error);

            return snapshot.hasData ? new ItemList(list: snapshot.data,) : new Center(
              child: CircularProgressIndicator(),
            );
          },
        )
      ),
    );
  }
}

class ItemList extends StatelessWidget {

  final List list;
  ItemList({this.list});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: list == null ? 0:list.length,
      itemBuilder: (context, i){
        return new Card(
      child: InkWell(
        splashColor: Colors.blue.withAlpha(30),
        // onTap: () => Navigator.of(context).push(new MaterialPageRoute(
        //           builder: (BuildContext context) => new Cobadetail(list: list, index: i,),
        //         )),
        child: Container(
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              Expanded(
                /*1*/
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    /*2*/
                    Container(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Text(
                        list[i]['customername'],
                        // list[i]['customerid'] == null ? list[i]['customername'] : list[i]['cname'],
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                    ),
                    Text(
                      list[i]['address'],
                      style: TextStyle(
                        color: Colors.grey[500],
                        fontSize: 18,
                      ),
                    ),
                    Text(
                      'Delivered At ${list[i]['date']}',
                       style: TextStyle(
                         fontSize: 18
                       ),
                    )
                  ],
                ),
              ),
              Container(
                height: 50,
                child: VerticalDivider(
                  color: Colors.grey[400],
                  thickness: 2,
                ),
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    child: Text(
                      'Zone',
                      style: TextStyle(fontSize: 18),
                    ),
                  ),
                  Text(
                    list[i]['zone'],
                    style:
                      TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
      },
      
    );
  }
}