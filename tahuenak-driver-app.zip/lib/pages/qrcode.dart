import 'package:first/main.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class Qrcode extends StatefulWidget {
  List list;
  int index;
  Qrcode({this.index, this.list});
  @override
  _QrcodeState createState() => _QrcodeState();
}

class _QrcodeState extends State<Qrcode> {
  bool visible = false;
  Future finish() async {
    // Showing CircularProgressIndicator.
    setState(() {
      visible = true;
    });

    // Getting value from Controller
    String id = widget.list[widget.index]['orderid'];

    // SERVER API URL
    // var url = 'http://trackingalkitab.epizy.com/driver_signup2.php';
    // alternate server https://projectalpha.sytes.net/mobile/driver_finish_order.php
    // server bapaknya http://tahuenak.id/mobile/driver_finish_order.php
    var url = 'https://tahuenak.id/mobile/driver_finish_order.php';
    // Store all data with Param Name.
    var data = {
      'id': id,
    };

    // Starting Web API Call.
    var response = await http.post(url, body: json.encode(data));

    // Getting Server response into variable.
    var message = jsonDecode(response.body);

    // If Web call Success than Hide the CircularProgressIndicator.
    if (response.statusCode == 200) {
      setState(() {
        visible = false;
      });
    }

    // Showing Alert Dialog with Response JSON Message.
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: new Text(message),
          actions: <Widget>[
            FlatButton(
              child: new Text("OK"),
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pop();
                Navigator.of(context).push(MaterialPageRoute(
                                builder: (BuildContext context) => MyApp(),
                              ));
              },
            ),
          ],
        );
      },
    );
  }
  Widget gbr = Container(
    width: 100,
    height: 100,
    child: Image.asset(
      'images/qr.jpg',
    fit: BoxFit.cover,
    )

  );

  final profilPic = Hero(
        tag: 'hero',
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Image.asset('images/qr.jpg')
        ));
  @override
  Widget build(BuildContext context) {
    final buttonSelesai = Padding(
      padding: EdgeInsets.all(16),
      child: RaisedButton(
        onPressed: finish,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        padding: EdgeInsets.all(12),
        color: Theme.of(context).primaryColor,
        child: Text(
          'Selesai',
          style: TextStyle(color: Colors.white),
        ),
      ),
    );
    return Scaffold(
      
        appBar: AppBar(
          title: Text('QR Code'),
        ),
        body: Center(
          child: ListView(
            children: <Widget>[
              profilPic,
              buttonSelesai,
              Column(
                children: <Widget>[
                  Visibility(visible: visible,child: CircularProgressIndicator()),
                ],
              ),
              // Text(
              //   widget.list[widget.index]['orderid']
              // )
            ],
          )
        ),
      
    );
  }
}