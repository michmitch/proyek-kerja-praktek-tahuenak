// import 'package:first/pages/addots.dart';
import 'package:flutter/material.dart';
import 'package:first/pages/detail.dart';
import 'package:http/http.dart' as http;
// import 'package:first/pages/login.dart' as login;
import 'package:first/global.dart' as globals;
import 'dart:convert';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  String username = globals.user;
  // alternate server http://trackingalkitab.000webhostapp.com/driver_get_list.php/?user=$username
  // https://projectalpha.sytes.net/mobile/driver_get_list.php/?user=$username
  // server bapaknya http://tahuenak.id/mobile/driver_get_list.php/?user=$username
  // var date = new DateTime.now().toString();
  // var dateParse = DateTime.parse(DateTime.now().toString());
  // var formatDate = "${DateTime.parse(DateTime.now().toString()).day}-${DateTime.parse(DateTime.now().toString()).month}-${DateTime.parse(DateTime.now().toString()).year}";
  // var finalDate = "${DateTime.parse(DateTime.now().toString()).day}-${DateTime.parse(DateTime.now().toString()).month}-${DateTime.parse(DateTime.now().toString()).year}".toString();
  Future<List> getData() async {
    final response = await http
        .get("https://tahuenak.id/mobile/driver_get_list.php/?user=$username");
    return jsonDecode(response.body);
  }

  Widget card = Card(
    child: InkWell(
      splashColor: Colors.blue.withAlpha(30),
      onTap: () {
        print('tapped');
      },
      child: Container(
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            Expanded(
              /*1*/
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  /*2*/
                  Container(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Text(
                      'Customer Name',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                  ),
                  Text(
                    'Customer Address',
                    style: TextStyle(
                      color: Colors.grey[500],
                      fontSize: 18,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 50,
              child: VerticalDivider(
                color: Colors.grey[400],
                thickness: 2,
              ),
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  child: Text(
                    'Zone',
                    style: TextStyle(fontSize: 18),
                  ),
                ),
                Text('A',
                    style:
                        TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              ],
            ),
          ],
        ),
      ),
    ),
  );

  Widget gbr = Image.asset(
    'images/try.jpg',
    width: 600,
    height: 240,
    fit: BoxFit.cover,
  );
  Widget namaDriver = Container(
    padding: EdgeInsets.all(16),
    child: Row(
      children: [
        Icon(
          Icons.account_circle,
          color: Colors.grey,
          size: 50,
        ),
        Padding(
            padding: EdgeInsets.only(left: 10),
            child: Text(
              'Nama Driver',
              style: TextStyle(fontSize: 18),
            )),
      ],
    ),
  );

  Widget tgl = Container(
    padding: EdgeInsets.all(16),
    child: Row(
      children: [
        Text(
          'Senin, 20 April 2020',
          style: TextStyle(fontSize: 18),
        )
      ],
    ),
  );

  Widget divider = Container(
    padding: EdgeInsets.symmetric(horizontal: 16),
    height: 20,
    child: Divider(
      color: Colors.grey[500],
      thickness: 2,
      height: 10,
    ),
  );
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Home',
      home: Scaffold(
        appBar: AppBar(
          title: Text('Home'),
        ),
        body: 
            FutureBuilder<List>(
              future: getData(),
              builder: (context, snapshot) {
                if (snapshot.hasError) print(snapshot.error);

                return snapshot.hasData
                    ? new OrderList(
                        list: snapshot.data,
                      )
                    : new Center(
                        child: CircularProgressIndicator(),
                      );
              },
            ),
        //  floatingActionButton: FloatingActionButton.extended(
        //    onPressed: () => Navigator.of(context).push(MaterialPageRoute(
        //           builder: (BuildContext context) => Addots(),
        //         )),
        //    label: Text('Add OTS'),
        //    icon: Icon(Icons.add),
        //    backgroundColor: Colors.lightBlue,
        //  ) 
        
      ),
    );
  }
}

class OrderList extends StatelessWidget {
  Container getNamaDriver(String nama){
    return Container(
    padding: EdgeInsets.all(16),
    child: Row(
      children: [
        Icon(
          Icons.account_circle,
          color: Colors.grey,
          size: 50,
        ),
        Padding(
            padding: EdgeInsets.only(left: 10),
            child: Text(
              nama,
              style: TextStyle(fontSize: 18),
            )),
      ],
    ),
  );
  }
  // Widget namaDriver = Container(
  //   padding: EdgeInsets.all(16),
  //   child: Row(
  //     children: [
  //       Icon(
  //         Icons.account_circle,
  //         color: Colors.grey,
  //         size: 50,
  //       ),
  //       Padding(
  //           padding: EdgeInsets.only(left: 10),
  //           child: Text(
  //             'Nama Driver',
  //             style: TextStyle(fontSize: 18),
  //           )),
  //     ],
  //   ),
  // );

  Widget tgl = Container(
    padding: EdgeInsets.all(16),
    child: Row(
      children: [
        Text(
          'Senin, 20 April 2020',
          style: TextStyle(fontSize: 18),
        )
      ],
    ),
  );

  Widget divider = Container(
    padding: EdgeInsets.symmetric(horizontal: 16),
    height: 20,
    child: Divider(
      color: Colors.grey[500],
      thickness: 2,
      height: 10,
    ),
  );
  var finalDate = "${DateTime.parse(DateTime.now().toString()).day}-${DateTime.parse(DateTime.now().toString()).month}-${DateTime.parse(DateTime.now().toString()).year}".toString();
  final List list;
  OrderList({this.list});
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: list == null ? 0 : list.length + 1,
        itemBuilder: (context, i) {
          if (i == 0) {
            return Column(
              children: <Widget>[

                getNamaDriver(globals.user),
                divider,
                Container(
    padding: EdgeInsets.all(16),
    child: Row(
      children: [
        Text(
          finalDate,
          style: TextStyle(fontSize: 18),
        )
      ],
    ),
  ),
              ],
            );
          }
          i -= 1;

          return Card(
            child: InkWell(
              splashColor: Colors.blue.withAlpha(30),
              onTap: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (BuildContext context) => Detail(list: list, index: i,),
                )),
              child: Container(
                padding: const EdgeInsets.all(20),
                child: Row(
                  children: [
                    Expanded(
                      /*1*/
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          /*2*/
                          Container(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: Text(
                              list[i]['customername'],
                              // list[i]['adminid'] != null ? list[i]['customername'] : list[i]['cname'],
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              ),
                            ),
                          ),
                          Text(
                            list[i]['address'],
                            style: TextStyle(
                              color: Colors.grey[500],
                              fontSize: 18,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      height: 50,
                      child: VerticalDivider(
                        color: Colors.grey[400],
                        thickness: 2,
                      ),
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          child: Text(
                            'Zone',
                            style: TextStyle(fontSize: 18),
                          ),
                        ),
                        
                        Text(list[i]['zone'],
                            style: TextStyle(
                                fontSize: 22, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        });
  }
}
