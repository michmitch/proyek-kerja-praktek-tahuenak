import 'package:flutter/material.dart';
import 'package:first/pages/login.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class Signup extends StatefulWidget {
  @override
  _SignupState createState() => _SignupState();
}

class _SignupState extends State<Signup> {
  TextEditingController controllerUsername = new TextEditingController();
  TextEditingController controllerPassword = new TextEditingController();
  TextEditingController controllerEmail = new TextEditingController();
  TextEditingController controllerAddress = new TextEditingController();
  // TextEditingController controllerZone = new TextEditingController();
  TextEditingController controllerPhone = new TextEditingController();

  TextInputType number = TextInputType.number;
  TextInputType email = TextInputType.emailAddress;
  TextInputType biasa = TextInputType.text;
  TextInputType telpon = TextInputType.phone;

  bool visible = false;

  Future userRegistration() async {
    // Showing CircularProgressIndicator.
    setState(() {
      visible = true;
    });

    // Getting value from Controller
    String username = controllerUsername.text;
    String password = controllerPassword.text;
    String email = controllerEmail.text;
    String address = controllerAddress.text;
    // String zone = controllerZone.text;
    String phone = controllerPhone.text;

    // SERVER API URL
    // var url = 'http://trackingalkitab.epizy.com/driver_signup2.php';
    // alternate server https://projectalpha.sytes.net/mobile/driver_signup3.php
    // server bapaknya http://tahuenak.id/mobile/driver_signup3.php 
    var url = 'https://tahuenak.id/mobile/driver_signup3.php';
    // Store all data with Param Name.
    var data = {
      'username': username,
      'password': password,
      'email': email,
      'address': address,
      // 'zone': zone,
      'phone': phone
    };

    // Starting Web API Call.
    var response = await http.post(url, body: json.encode(data));

    // Getting Server response into variable.
    var message = jsonDecode(response.body);

    // If Web call Success than Hide the CircularProgressIndicator.
    if (response.statusCode == 200) {
      setState(() {
        visible = false;
      });
    }

    // Showing Alert Dialog with Response JSON Message.
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: new Text(message),
          actions: <Widget>[
            FlatButton(
              child: new Text("OK"),
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
  // void signUp(){
  //   print('sign up');
  //   var url = 'http://trackingalkitab.epizy.com/driver_signup.php';

  //   http.post(
  //     url,
  //     body: {
  //       "username": controllerUsername.text,
  //       "password": controllerPassword.text,
  //       "email": controllerEmail.text,
  //       "address": controllerAddress.text,
  //       "zone": controllerZone.text,
  //       "phone": controllerPhone.text,
  //     }
  //   );

  // }

  @override
  Widget build(BuildContext context) {
    final profilPic = Hero(
        tag: 'hero',
        child: Padding(
          padding: EdgeInsets.all(16),
          child: CircleAvatar(
            radius: 100,
            backgroundColor: Colors.transparent,
            backgroundImage: AssetImage('images/tahu2.png'),
          ),
        ));

    final buttonSignUp = RaisedButton(
      onPressed: userRegistration,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(80.0),
      ),
      padding: const EdgeInsets.all(0.0),
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: <Color>[Color(0xFF13E3D2), Color(0xFF5D74E2)],
          ),
          borderRadius: BorderRadius.all(
            Radius.circular(80.0),
          ),
        ),
        constraints: const BoxConstraints(
          minWidth: 150.0,
          minHeight: 36.0,
        ),
        alignment: Alignment.center,
        child: const Text(
          'Signup',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 18
          ),
        ),
      ),
    );

    return MaterialApp(
      title: 'Signup',
      home: Scaffold(
          appBar: AppBar(
            title: Text('Signup'),
          ),
          body: Center(
            child: ListView(
              children: <Widget>[
                Column(children: [profilPic]),
                
                _buildForm('Username',controllerUsername, biasa, false),
                _buildForm('Password', controllerPassword, biasa, true),
                _buildForm('Email', controllerEmail, email, false),
                _buildForm('Adddress', controllerAddress, biasa, false),
                // _buildForm('Zone', controllerZone, biasa, false),
                _buildForm('Phone', controllerPhone, telpon, false),
                
                Container(
                  padding: EdgeInsets.all(16),
                  child: Column(
                    children: <Widget>[
                      buttonSignUp,
                    ],
                  ),
                ),
                Column(
                  children: <Widget>[
                    Visibility(
                        visible: visible,
                        child: Container(
                            margin: EdgeInsets.only(bottom: 30),
                            child: CircularProgressIndicator())),
                  ],
                ),
                Container(
                  padding: EdgeInsets.all(16),

                  child: Column(
                    children: <Widget>[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text('Already have account? ',
                          style: TextStyle(fontSize: 18),),
                          FlatButton(
                            onPressed: () =>
                              Navigator.of(context).push(new MaterialPageRoute(
                                builder: (BuildContext context) => new Login(),
                              )),
                            child: Text(
                              'Login',
                              style: TextStyle(
                                color: Colors.blue[400],
                                fontWeight: FontWeight.bold,
                                fontSize: 18
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          )),
    );
  }
  

  Container _buildForm(String label, TextEditingController control, TextInputType tipe, bool pass) {
    return Container(
      padding: EdgeInsets.all(16),
      child: Column(
        children: [
          TextFormField(
            
            controller: control,
            keyboardType: tipe,
            obscureText: pass,
            decoration: InputDecoration(
              focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                  color: Colors.lightBlueAccent,
                ),
              ),
              labelText: label,
              labelStyle: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
