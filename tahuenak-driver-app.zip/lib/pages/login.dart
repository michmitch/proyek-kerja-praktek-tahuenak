import 'package:first/main.dart';
import 'package:first/pages/signup.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:first/global.dart' as globals;
class Login extends StatefulWidget {
  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  TextEditingController controllerUsername = new TextEditingController();
  TextEditingController controllerPassword = new TextEditingController();

  bool visible = false;

  Future userLogin() async{

  // Showing CircularProgressIndicator.
  setState(() {
  visible = true ; 
  });

  print(globals.user);

  // Getting value from Controller
  String username = controllerUsername.text;
  String password = controllerPassword.text;
  globals.user = username;
  // SERVER LOGIN API URL
  // alternate server http://trackingalkitab.000webhostapp.com/driver_login.php
  // alternate server https://projectalpha.sytes.net/mobile/driver_login.php  
  // server bapaknya http://tahuenak.id/mobile/driver_login.php
  var url = 'https://tahuenak.id/mobile/driver_login.php';

  // Store all data with Param Name.
  var data = {'username': username, 'password' : password};

  // Starting Web API Call.
  // var response = await http.post(url, body: json.encode(data));
  var response = await http.post(url, body: json.encode(data));

  // Getting Server response into variable.
  var message = jsonDecode(response.body);
  // var split = message.split(" ");
  // globals.driverid = split[2];
  // globals.reselid = split[3];
  // If the Response Message is Matched.
  if(message == 'Login Matched')
  {

    // Hiding the CircularProgressIndicator.
      setState(() {
        controllerPassword.clear();
        controllerUsername.clear();
        visible = false; 
      });

    
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => MyApp())
      );
  }else{

    // If did not Matched.
    // Hiding the CircularProgressIndicator.
    setState(() {
      visible = false; 
      });

    // Showing Alert Dialog with Response JSON Message.
    showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: new Text(message),
        actions: <Widget>[
          FlatButton(
            child: new Text("OK"),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ],
      );
    },
    );}

}

  @override
  Widget build(BuildContext context) {
    final profilPic = Hero(
        tag: 'hero',
        child: Padding(
          padding: EdgeInsets.all(16),
          child: CircleAvatar(
            radius: 100,
            backgroundColor: Colors.transparent,
            backgroundImage: AssetImage('images/tahu2.png'),
          ),
        ));

    final buttonLogin = RaisedButton(
      onPressed: userLogin,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(80.0),
      ),
      padding: const EdgeInsets.all(0.0),
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: <Color>[Color(0xFF13E3D2), Color(0xFF5D74E2)],
          ),
          borderRadius: BorderRadius.all(
            Radius.circular(80.0),
          ),
        ),
        constraints: const BoxConstraints(
          minWidth: 150.0,
          minHeight: 36.0,
        ),
        alignment: Alignment.center,
        child: const Text(
          'Login',
          textAlign: TextAlign.center,
          style: TextStyle(
              color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18),
        ),
      ),
    );

    return MaterialApp(
          title: 'Login',
          debugShowCheckedModeBanner: false,
          home: Scaffold(
            appBar: AppBar(
            title: Text('Login'),
          ),
          body: Center(
            child: ListView(
              children: <Widget>[
                Column(children: [profilPic]),
                _buildForm('Username', controllerUsername, false),
                _buildForm('Password', controllerPassword, true),
                Container(
                  padding: EdgeInsets.all(16),
                  child: Column(
                    children: <Widget>[
                      buttonLogin,
                      Visibility(
                        visible: visible, 
                        child: Container(
                          margin: EdgeInsets.only(bottom: 30),
                          child: CircularProgressIndicator()
                        )
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            'Dont have account? ',
                            style: TextStyle(fontSize: 18),
                          ),
                          FlatButton(
                            onPressed: () => Navigator.of(context)
                                .push(new MaterialPageRoute(
                              builder: (BuildContext context) => new Signup(),
                            )),
                            child: Text(
                              'Register',
                              style: TextStyle(
                                color: Colors.blue[400],
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        )
    );
  }

  Container _buildForm(String label, TextEditingController control, bool pass) {
    return Container(
      padding: EdgeInsets.all(16),
      child: Column(
        children: [
          TextField(
            controller: control,
            obscureText: pass,
            decoration: InputDecoration(
              focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                  color: Colors.lightBlueAccent,
                ),
              ),
              labelText: label,
              labelStyle: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
