import 'dart:io';

import 'package:first/pages/login.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:first/global.dart' as globals;


class Profile extends StatefulWidget {
  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  Future<List> getProfile() async {
    String username = globals.user;
    var url = 'https://tahuenak.id/mobile/driver_get_profile.php?user=$username';
    final response = await http.get(url);
    return json.decode(response.body);
  }
  @override
  Widget build(BuildContext context) {
    final profilPic = Hero(
        tag: 'hero',
        child: Padding(
          padding: EdgeInsets.all(16),
          child: CircleAvatar(
            radius: 72,
            backgroundColor: Colors.transparent,
            backgroundImage: AssetImage('images/interface.png'),
          ),
        ));
    final welcome = Padding(
      padding: EdgeInsets.all(8),
      child: Text(
        'Welcome',
        style: TextStyle(fontSize: 28, color: Colors.white),
      ),
    );

    final lorem = Padding(
      padding: EdgeInsets.all(8),
      child: Text(
        'Lorem ipsum dolor sit amet',
        style: TextStyle(
          fontSize: 16,
          color: Colors.white,
        ),
      ),
    );

    final buttonSignOut = Padding(
      padding: EdgeInsets.all(16),
      child: RaisedButton(
        // onPressed: () => Navigator.of(context).pushReplacement(MaterialPageRoute(
        //   builder: (BuildContext context) => Login(),
        // )),
        // onPressed:(){
        //   Navigator.of(context).pop();
        // },
        onPressed: () => exit(0),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        padding: EdgeInsets.all(12),
        color: Theme.of(context).primaryColor,
        child: Text(
          'Sign Out',
          style: TextStyle(color: Colors.white),
        ),
      ),
    );

    final bod = Container(
      width: MediaQuery.of(context).size.width,
      padding: EdgeInsets.all(28),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [
          Colors.blue,
          Colors.lightBlueAccent,
        ]),
      ),
      child: Column(
        children: <Widget>[profilPic, welcome, lorem, buttonSignOut],
      ),
    );

    Widget dataDiri = Container(
      padding: EdgeInsets.all(16),
      child: Row(
        children: [
          Text(
            'Nama Driver',
            style: TextStyle(fontSize: 18),
          ),
        ],
      ),
    );

    Widget divider = Container(
      padding: EdgeInsets.symmetric(horizontal: 16),
      height: 10,
      child: Divider(
        color: Colors.grey[500],
        thickness: 2,
        height: 6,
      ),
    );

    return MaterialApp(
      title: 'Profile',
      home: Scaffold(
          appBar: AppBar(
            title: Text('Profile'),
          ),
          body: FutureBuilder<List>(
            future: getProfile(),
            builder: (context, snapshot){
              return snapshot.hasData ? new DataDriver(list: snapshot.data) : new Center(child: CircularProgressIndicator(),);
            }
          )
          ),
    );
  }

  Container _buildDataDiri(String label, String isi) {
    return Container(
      padding: EdgeInsets.all(16),
      child: Column(
        children: [
          Row(
            children: <Widget>[
              Text(
                label,
                style: TextStyle(fontSize: 18),
              ),
            ],
          ),
          Row(
            children: <Widget>[
              Text(
                isi,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class DataDriver extends StatelessWidget {
  
  List list;
  DataDriver({this.list});
  @override
  Widget build(BuildContext context) {
    final buttonSignOut = Padding(
      padding: EdgeInsets.all(16),
      child: RaisedButton(
        // onPressed: () => Navigator.of(context).pushReplacement(MaterialPageRoute(
        //   builder: (BuildContext context) => Login(),
        // )),
        onPressed: (){
          showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: new Text('Sign Out?'),
          actions: <Widget>[
            FlatButton(
              child: new Text("No"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            FlatButton(
              child: new Text("Yes"),
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
          
        },
        // onPressed: (){
        //   Navigator.of(context).pushReplacement(
        //     MaterialPageRoute(
        //       builder: (BuildContext context) => Login(),
        //     )
        //   );
        //   Navigator.of(context).pop();

        // },
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        padding: EdgeInsets.all(12),
        color: Theme.of(context).primaryColor,
        child: Text(
          'Sign Out',
          style: TextStyle(color: Colors.white),
        ),
      ),
    );

    final profilPic = Hero(
        tag: 'hero',
        child: Padding(
          padding: EdgeInsets.all(16),
          child: CircleAvatar(
            radius: 72,
            backgroundColor: Colors.transparent,
            backgroundImage: AssetImage('images/default.jpg'),
          ),
        ));

    Widget divider = Container(
      padding: EdgeInsets.symmetric(horizontal: 16),
      height: 10,
      child: Divider(
        color: Colors.grey[500],
        thickness: 2,
        height: 6,
      ),
    );

    Container _buildDataDiri(String label, String isi) {
    return Container(
      padding: EdgeInsets.all(16),
      child: Column(
        children: [
          Row(
            children: <Widget>[
              Text(
                label,
                style: TextStyle(fontSize: 18),
              ),
            ],
          ),
          Row(
            children: <Widget>[
              Text(
                isi,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ],
      ),
    );
  }
    return ListView.builder(
      itemCount: list == null ? 0 : list.length,
      itemBuilder: (context, i){
        return Column(
      
            children: <Widget>[
              Column(children: <Widget>[profilPic],),
              _buildDataDiri('Username', list[i]['username']),
              divider,
              _buildDataDiri('Email', list[i]['email']),
              divider,
              _buildDataDiri('Alamat', list[i]['address']),
              divider,
              _buildDataDiri('Nomor Telepon', list[i]['phone']),
              divider,
              _buildDataDiri('Zone', list[i]['zone']),
              divider,
              Column(
                children: <Widget>[
                  buttonSignOut,
                ],
              ),
            ],
          
        );
      },
    );
  }
}
